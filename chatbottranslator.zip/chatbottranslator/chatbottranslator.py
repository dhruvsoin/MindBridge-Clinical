import asyncio
import re
import json
from typing import List, Dict, Any, Optional, Set
import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from PyCharacterAI import get_client
from PyCharacterAI.exceptions import SessionClosedError
from dotenv import load_dotenv
# RAG and AI Libraries
from groq import Groq
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings.fastembed import FastEmbedEmbeddings
from langchain.docstore.document import Document
from langchain_groq import ChatGroq
import hashlib

load_dotenv()

# Configuration
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
CHARACTER_AI_TOKEN = "8bffea7f61747077512e09269760e1db113b59e7"
CHARACTER_ID = "Xqr1QCxyTmqZsDKmiVq_yyAWHqXJ4SVpv7LvNTY450E"

# FastAPI App
app = FastAPI(title="Multilingual Mental Health API", version="1.0.0")

# Pydantic Models
class AnalysisRequest(BaseModel):
    prompt: str

class Analysis(BaseModel):
    detected_conditions: List[str]
    is_serious: bool
    recommended_specialty: str
    explanation: str

class Specialist(BaseModel):
    doctor_id: str
    name: str
    specialization: str
    category: str
    phone: str
    experience: int

class AnalysisResponse(BaseModel):
    response: str
    analysis: Analysis
    specialists: Optional[List[Specialist]]
    is_serious: bool

# Load doctors data
def load_doctors_data():
    """Load doctors from JSON file"""
    try:
        with open("dataset.json", 'r', encoding='utf-8') as f:
            doctors_data = json.load(f)
            print(f"✅ Successfully loaded {len(doctors_data)} counselors from dataset.json")
            return doctors_data
    except FileNotFoundError:
        print(f"❌ Error: dataset.json not found!")
        return []
    except json.JSONDecodeError as e:
        print(f"❌ Error: Invalid JSON format: {e}")
        return []
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        return []

doctors_data = load_doctors_data()

class LanguageManager:
    """Enhanced language manager with special Hinglish support"""
    
    def __init__(self, groq_client: Groq):
        self.groq_client = groq_client
        
        # Common Hinglish patterns and indicators
        self.hinglish_indicators = [
            "yaar", "bhai", "didi", "ji", "haan", "nahi", "kya", "kaise", "kaun", 
            "kahan", "kab", "kyun", "acha", "theek", "sahi", "galat", "samjha",
            "pata", "malum", "dekho", "suno", "bolo", "karo", "chalo", "aao",
            "jao", "raho", "hello ji", "ok yaar", "great yaar", "nice bhai",
            "main", "mein", "hoon", "hun", "hai", "tha", "thi", "the", "kar", 
            "kya kar", "kaise ho", "kya haal", "thik hai", "sab theek", "bahut", 
            "bohot", "achha", "accha", "bura", "buraa", "aur", "or", "phir", "fir",
            "yaar main", "bhai main", "actually yaar", "seriously yaar",
            "honestly bhai", "matlab", "bas yaar", "are yaar", "arre bhai"
        ]
    
    def is_hinglish(self, text: str) -> bool:
        """Detect if text is Hinglish (Hindi-English code-mixed)"""
        text_lower = text.lower()
        
        # Count Hinglish indicators
        hinglish_score = 0
        for indicator in self.hinglish_indicators:
            if indicator in text_lower:
                hinglish_score += 1
        
        # Check for mixed script patterns
        roman_hindi_patterns = [
            r'\b(kar|hai|hoon|main|mein|yaar|bhai)\b',
            r'\b(kya|kaise|kaun|kahan|kab|kyun)\b',
            r'\b(achha|theek|sahi|galat|bahut)\b'
        ]
        
        if hinglish_score >= 1 or any(re.search(pattern, text_lower) for pattern in roman_hindi_patterns):
            return True
            
        return False
    
    def detect_language(self, text: str) -> str:
        """Detect language of input text with special Hinglish handling"""
        
        if self.is_hinglish(text):
            return "Hinglish"
        
        # Quick check for pure English
        english_indicators = ["the", "and", "or", "but", "is", "are", "was", "were", "have", "has", "will", "would", "could", "should"]
        text_lower = text.lower()
        
        english_word_count = sum(1 for word in english_indicators if word in text_lower)
        if english_word_count >= 2 and not re.search(r'[^a-zA-Z0-9\s.,!?\'"-]', text):
            return "English"
        
        # Use Groq for complex language detection
        detection_prompt = f"""
        Detect the language of this text. Reply with ONLY one word from these options:
        - English
        - Hindi  
        - Hinglish (for Hindi-English mixed text)
        - Spanish
        - French
        - German
        - Tamil
        - Telugu
        - Bengali
        - Other
        
        Text: "{text}"
        
        Language:
        """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": detection_prompt}],
                temperature=0.1,
                max_tokens=50
            )
            
            detected = response.choices[0].message.content.strip()
            return detected
            
        except Exception as e:
            print(f"❌ Language detection error: {e}")
            return "English"
    
    def translate_to_english(self, text: str, source_language: str) -> str:
        """Translate text to English with enhanced Hinglish support"""
        
        if source_language.lower() == "english":
            return text
        
        if source_language.lower() == "hinglish":
            translate_prompt = f"""
            You are an expert in Hinglish (Hindi-English code-mixed language) translation.
            
            Translate this Hinglish text to clear, natural English while preserving:
            1. The emotional tone and intensity
            2. Cultural context and meaning
            3. Informal/formal register as appropriate
            
            Examples:
            - "Yaar main bahut sad hun" → "Friend, I am very sad"  
            - "Bhai seriously depression mein hun" → "Brother, I'm seriously in depression"
            - "Main kya karu yaar, life mein kuch theek nahi ja raha" → "What should I do friend, nothing is going right in my life"
            
            Hinglish text: "{text}"
            
            English translation:
            """
        else:
            translate_prompt = f"""
            Translate the following text from {source_language} to English. 
            Preserve the emotional tone, cultural context, and meaning.
            Provide only the English translation, nothing else.
            
            Text: "{text}"
            
            Translation:
            """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": translate_prompt}],
                temperature=0.2,
                max_tokens=200
            )
            
            translation = response.choices[0].message.content.strip()
            
            if (translation.startswith('"') and translation.endswith('"')) or (translation.startswith("'") and translation.endswith("'")):
                translation = translation[1:-1]
                
            return translation
            
        except Exception as e:
            print(f"❌ Translation to English error: {e}")
            return text
    
    def translate_from_english(self, text: str, target_language: str) -> str:
        """Translate English text back to target language with Hinglish support"""
        
        if target_language.lower() == "english":
            return text
            
        if target_language.lower() == "hinglish":
            translate_prompt = f"""
            You are an expert in Hinglish (Hindi-English code-mixed language).
            
            Translate this English text to natural Hinglish that Indians commonly use.
            Rules:
            1. Mix Hindi and English naturally like native speakers
            2. Use Roman script for Hindi words (no Devanagari)
            3. Keep common English words as they are
            4. Use popular Hinglish terms like "yaar", "bhai", "actually", etc.
            5. Maintain the emotional tone and meaning
            
            Examples:
            - "I am very sad" → "Main bahut sad hun yaar"
            - "I don't know what to do" → "Mujhe nahi pata kya karna hai"
            - "Everything is going wrong" → "Sab kuch galat ho raha hai"
            
            English text: "{text}"
            
            Hinglish translation:
            """
        else:
            translate_prompt = f"""
            Translate the following English text to {target_language}.
            Preserve the emotional tone, cultural context, and meaning.
            Make it sound natural for native speakers.
            Provide only the {target_language} translation, nothing else.
            
            English text: "{text}"
            
            Translation:
            """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile", 
                messages=[{"role": "user", "content": translate_prompt}],
                temperature=0.3,
                max_tokens=200
            )
            
            translation = response.choices[0].message.content.strip()
            
            if (translation.startswith('"') and translation.endswith('"')) or (translation.startswith("'") and translation.endswith("'")):
                translation = translation[1:-1]
                
            return translation
            
        except Exception as e:
            print(f"❌ Translation from English error: {e}")
            return text

class SeverityAnalyzer:
    """Analyze mental health severity and conditions"""
    
    def __init__(self, groq_client: Groq):
        self.groq_client = groq_client
        
        # Crisis indicators (multilingual)
        self.crisis_keywords = [
            # English
            "want to die", "wanna die", "kill myself", "suicide", "suicidal thoughts",
            "end my life", "better off dead", "take my own life", "harm myself",
            "can't go on", "no reason to live", "kms", "kys",
            
            # Hinglish
            "mar jaana chahta hun", "suicide kar lunga", "kill kar dunga", 
            "marr jaun", "khatam kar dena", "mar jaana hai", "jeena nahi chahta",
            "life mein kuch nahi", "kms kar", "marne ka soch rh",
            
            # Hindi (Roman)
            "marna chahta hun", "suicide karna hai", "marr jaana", "zindagi se pareshan"
        ]
    
    def detect_crisis(self, message: str) -> bool:
        """Detect if message contains crisis indicators"""
        message_lower = message.lower().strip()
        
        for keyword in self.crisis_keywords:
            if keyword in message_lower:
                return True
        return False
    
    def analyze_conditions(self, message: str, language: str) -> Dict[str, Any]:
        """Analyze mental health conditions and severity"""
        
        analysis_prompt = f"""
        You are a mental health assessment AI. Analyze this message for mental health conditions.
        
        Rules:
        1. Identify specific mental health conditions if clearly indicated
        2. Assess severity: SERIOUS (crisis/severe symptoms) vs NON-SERIOUS (mild/vague symptoms)
        3. Consider cultural and language context
        4. Be conservative - only mark as SERIOUS if there are clear crisis indicators
        
        Message: "{message}"
        Language: {language}
        
        Respond in this exact JSON format:
        {{
            "conditions": ["condition1", "condition2"],
            "is_serious": true/false,
            "specialty": "specialty_name or None",
            "explanation": "brief clinical reasoning"
        }}
        
        Condition examples: "Severe Depression", "Suicidal Thoughts", "Anxiety", "Stress", "Mild Depression", "vague symptoms"
        Specialty examples: "Psychiatry", "Clinical Psychology", "None"
        """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": analysis_prompt}],
                temperature=0.1,
                max_tokens=300
            )
            
            result = response.choices[0].message.content.strip()
            
            # Parse JSON response
            try:
                parsed = json.loads(result)
                return {
                    "detected_conditions": parsed.get("conditions", ["vague symptoms"]),
                    "is_serious": parsed.get("is_serious", False),
                    "recommended_specialty": parsed.get("specialty", "None"),
                    "explanation": parsed.get("explanation", "Assessment completed.")
                }
            except json.JSONDecodeError:
                # Fallback if JSON parsing fails
                is_crisis = self.detect_crisis(message)
                return {
                    "detected_conditions": ["Severe Depression", "Crisis"] if is_crisis else ["vague symptoms"],
                    "is_serious": is_crisis,
                    "recommended_specialty": "Psychiatry" if is_crisis else "None",
                    "explanation": "Crisis indicators detected." if is_crisis else "Mild symptoms observed."
                }
                
        except Exception as e:
            print(f"❌ Analysis error: {e}")
            # Conservative fallback
            is_crisis = self.detect_crisis(message)
            return {
                "detected_conditions": ["Crisis"] if is_crisis else ["vague symptoms"],
                "is_serious": is_crisis,
                "recommended_specialty": "Psychiatry" if is_crisis else "None",
                "explanation": "Emergency assessment due to analysis error." if is_crisis else "Unable to complete full assessment."
            }

class MessageCensor:
    """Censor messages for Character.AI TOS compliance"""
    
    def __init__(self, groq_client: Groq):
        self.groq_client = groq_client
        
        self.violation_indicators = [
            "kms", "kys", "kill myself", "kill yourself", "suicide", "suicidal",
            "self harm", "self-harm", "end my life", "want to die", "wanna die",
            "mar jaana chahta", "suicide kar lunga", "kill kar dunga", "kms kar",
            "marna chahta hun", "suicide karna hai"
        ]
    
    def needs_censoring(self, message: str) -> bool:
        """Check if message needs censoring"""
        message_lower = message.lower().strip()
        for indicator in self.violation_indicators:
            if indicator in message_lower:
                return True
        return False
    
    def censor_message(self, message: str) -> str:
        """Censor message while preserving meaning"""
        
        if not self.needs_censoring(message):
            return message
        
        censor_prompt = f"""
        Sanitize this message to avoid platform violations while preserving emotional content:
        
        Rules:
        1. Remove explicit self-harm/suicide language
        2. Keep the same emotional tone and urgency
        3. Maintain the original language (English/Hinglish/Hindi)
        4. Make minimal changes
        
        Examples:
        - "I want to kill myself" → "I'm feeling extremely hopeless"
        - "Yaar main mar jaana chahta hun" → "Yaar main bahut desperate feel kar raha hun"
        
        Original: "{message}"
        
        Sanitized version:
        """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": censor_prompt}],
                temperature=0.1,
                max_tokens=150
            )
            
            censored = response.choices[0].message.content.strip()
            
            if (censored.startswith('"') and censored.endswith('"')) or (censored.startswith("'") and censored.endswith("'")):
                censored = censored[1:-1]
                
            return censored
            
        except Exception as e:
            print(f"❌ Censoring error: {e}")
            # Basic fallback replacements
            replacements = {
                "kill myself": "feel hopeless", "suicide": "giving up", "kms": "feeling down",
                "mar jaana chahta": "bahut sad hun", "suicide kar lunga": "hopeless feel kar raha hun"
            }
            
            censored = message.lower()
            for original, replacement in replacements.items():
                censored = censored.replace(original, replacement)
            return censored

class DoctorRecommendationRAG:
    """Enhanced RAG system with duplicate prevention"""
    
    def __init__(self, doctors_data: List[Dict], groq_api_key: str):
        self.doctors_data = doctors_data
        self.groq_client = Groq(api_key=groq_api_key)
        self.embeddings = FastEmbedEmbeddings(model_name="BAAI/bge-small-en-v1.5")
        self.vectorstore = None
        self.setup_vectorstore()
    
    def generate_unique_id(self, doctor: Dict) -> str:
        """Generate unique ID for doctor to prevent duplicates"""
        # Create unique identifier based on doctor's key attributes
        identifier_string = f"{doctor.get('name', '')}-{doctor.get('phone', '')}-{doctor.get('email', '')}"
        return hashlib.md5(identifier_string.encode()).hexdigest()
    
    def setup_vectorstore(self):
        """Setup vector database with unique document IDs"""
        if not self.doctors_data:
            return
            
        documents = []
        seen_doctors = set()  # Track unique doctors to prevent duplicates
        
        for doctor in self.doctors_data:
            # Generate unique identifier for this doctor
            unique_id = self.generate_unique_id(doctor)
            
            # Skip if we've already processed this doctor (duplicate prevention)
            if unique_id in seen_doctors:
                print(f"⚠️ Skipping duplicate doctor: {doctor.get('name', 'Unknown')}")
                continue
            
            seen_doctors.add(unique_id)
            
            # Format availability
            availability_text = "Not specified"
            if doctor.get('availability'):
                available_days = []
                for day_info in doctor.get('availability', []):
                    day = day_info.get('day', '')
                    slots = day_info.get('slots', [])
                    if slots:
                        available_days.append(f"{day}: {', '.join(slots)}")
                if available_days:
                    availability_text = "; ".join(available_days)
            
            doc_text = f"""
            Dr. {doctor.get('name', 'N/A')}
            Specialization: {doctor.get('specialization', 'N/A')}
            Category: {doctor.get('category', 'N/A')}
            Experience: {doctor.get('experience', 'N/A')} years
            Phone: {doctor.get('phone', 'N/A')}
            Email: {doctor.get('email', 'N/A')}
            Consultation Fee: ₹{doctor.get('consultationFee', 'N/A')}
            Availability: {availability_text}
            Qualifications: {', '.join(doctor.get('qualifications', []))}
            Status: {doctor.get('status', 'N/A')}
            """
            
            documents.append(Document(
                page_content=doc_text,
                metadata={
                    "doctor_id": doctor.get('userId', unique_id),
                    "unique_id": unique_id,  # Our generated unique ID
                    "name": doctor.get('name'),
                    "specialization": doctor.get('specialization'),
                    "category": doctor.get('category'),
                    "experience": doctor.get('experience'),
                    "phone": doctor.get('phone'),
                    "consultationFee": doctor.get('consultationFee')
                }
            ))
        
        try:
            self.vectorstore = Chroma.from_documents(
                documents=documents,
                embedding=self.embeddings,
                persist_directory="./doctor_chroma_db",
                ids=[doc.metadata["unique_id"] for doc in documents]  # Use unique IDs
            )
            print(f"✅ Vector database created with {len(documents)} unique doctors (removed duplicates)")
        except Exception as e:
            print(f"❌ Error creating vector database: {e}")
    
    def get_relevant_doctors(self, conditions: List[str], k: int = 3) -> List[Specialist]:
        """Get unique relevant doctors based on conditions"""
        if not self.vectorstore or not conditions:
            return []
        
        try:
            # Search for more documents initially to account for potential filtering
            search_k = min(k * 3, len(self.doctors_data))  # Search 3x more to ensure uniqueness
            
            query = f"mental health psychiatrist psychologist depression anxiety therapy counseling crisis {' '.join(conditions)}"
            docs = self.vectorstore.similarity_search(query, k=search_k)
            
            specialists = []
            seen_doctor_ids = set()  # Track unique doctors in results
            seen_names = set()  # Additional check by name
            seen_phones = set()  # Additional check by phone
            
            for doc in docs:
                metadata = doc.metadata
                
                # Multiple checks to ensure uniqueness
                doctor_id = metadata.get('doctor_id')
                unique_id = metadata.get('unique_id')
                name = metadata.get('name', '').lower().strip()
                phone = metadata.get('phone', '').strip()
                
                # Skip if we've seen this doctor already (multiple uniqueness checks)
                if (doctor_id in seen_doctor_ids or 
                    unique_id in seen_doctor_ids or 
                    name in seen_names or 
                    phone in seen_phones):
                    print(f"⚠️ Skipping duplicate in results: {metadata.get('name', 'Unknown')}")
                    continue
                
                # Add to seen sets
                if doctor_id:
                    seen_doctor_ids.add(doctor_id)
                if unique_id:
                    seen_doctor_ids.add(unique_id)
                if name:
                    seen_names.add(name)
                if phone:
                    seen_phones.add(phone)
                
                # Create specialist object
                specialists.append(Specialist(
                    doctor_id=doctor_id or unique_id or f"doc_{len(specialists)}",
                    name=metadata.get('name', 'N/A'),
                    specialization=metadata.get('specialization', 'N/A'),
                    category=metadata.get('category', 'N/A'),
                    phone=metadata.get('phone', 'N/A'),
                    experience=int(metadata.get('experience', 0)) if metadata.get('experience') else 0
                ))
                
                # Stop when we have enough unique specialists
                if len(specialists) >= k:
                    break
            
            print(f"✅ Found {len(specialists)} unique specialists from {len(docs)} search results")
            return specialists
            
        except Exception as e:
            print(f"❌ Doctor search error: {e}")
            return []

class CharacterAIManager:
    """Manage Character.AI interactions"""
    
    def __init__(self, token: str, character_id: str):
        self.token = token
        self.character_id = character_id
        self.client = None
    
    async def get_response(self, message: str) -> str:
        """Get single response from Character.AI"""
        try:
            if not self.client:
                self.client = await get_client(token=self.token)
            
            chat, _ = await self.client.chat.create_chat(self.character_id)
            
            # Send message and get response
            answer = await self.client.chat.send_message(
                self.character_id,
                chat.chat_id,
                message,
                streaming=False
            )
            
            # Extract response text
            if hasattr(answer, 'get_primary_candidate'):
                return answer.get_primary_candidate().text
            else:
                # Handle non-streaming response
                async for response in answer:
                    return response.get_primary_candidate().text
            
        except Exception as e:
            print(f"❌ Character.AI error: {e}")
            return "I'm here to listen and support you. Please know that you're not alone in this."

# Global instances
groq_client = Groq(api_key=GROQ_API_KEY)
language_manager = LanguageManager(groq_client)
severity_analyzer = SeverityAnalyzer(groq_client)
censor = MessageCensor(groq_client)
doctor_rag = DoctorRecommendationRAG(doctors_data, GROQ_API_KEY)
character_ai = CharacterAIManager(CHARACTER_AI_TOKEN, CHARACTER_ID)

@app.post("/analyze-mental-health", response_model=AnalysisResponse)
async def analyze_mental_health(request: AnalysisRequest):
    """Main endpoint for mental health analysis"""
    
    try:
        # Step 1: Detect language
        detected_language = language_manager.detect_language(request.prompt)
        print(f"🌐 Detected language: {detected_language}")
        
        # Step 2: Translate to English if needed
        english_prompt = request.prompt
        if detected_language.lower() != "english":
            english_prompt = language_manager.translate_to_english(request.prompt, detected_language)
            print(f"🔄 Translated to English: {english_prompt}")
        
        # Step 3: Analyze severity and conditions
        analysis_result = severity_analyzer.analyze_conditions(request.prompt, detected_language)
        print(f"📊 Analysis: {analysis_result}")
        
        # Step 4: Censor message for Character.AI
        censored_prompt = censor.censor_message(english_prompt)
        print(f"🔍 Censored: {censored_prompt}")
        
        # Step 5: Get Character.AI response
        ai_response = await character_ai.get_response(censored_prompt)
        print(f"🤖 Character.AI response: {ai_response}")
        
        # Step 6: Translate response back if needed
        final_response = ai_response
        if detected_language.lower() != "english":
            final_response = language_manager.translate_from_english(ai_response, detected_language)
            print(f"🌐 Translated response: {final_response}")
        
        # Step 7: Get unique specialists if serious
        specialists = None
        if analysis_result["is_serious"]:
            specialists = doctor_rag.get_relevant_doctors(analysis_result["detected_conditions"], k=1)
            print(f"👨‍⚕️ Found {len(specialists) if specialists else 0} unique specialists")
            
            # Final check to ensure no duplicates in the response
            if specialists:
                unique_specialists = []
                seen_ids = set()
                seen_names = set()
                
                for spec in specialists:
                    spec_name_lower = spec.name.lower().strip()
                    if spec.doctor_id not in seen_ids and spec_name_lower not in seen_names:
                        seen_ids.add(spec.doctor_id)
                        seen_names.add(spec_name_lower)
                        unique_specialists.append(spec)
                
                specialists = unique_specialists[:3]  # Ensure maximum 3 unique specialists
                print(f"✅ Final unique specialists count: {len(specialists)}")
        
        # Step 8: Build response
        return AnalysisResponse(
            response=final_response,
            analysis=Analysis(
                detected_conditions=analysis_result["detected_conditions"],
                is_serious=analysis_result["is_serious"],
                recommended_specialty=analysis_result["recommended_specialty"],
                explanation=analysis_result["explanation"]
            ),
            specialists=specialists,
            is_serious=analysis_result["is_serious"]
        )
        
    except Exception as e:
        print(f"❌ API error: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "message": "Multilingual Mental Health API is running"}

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Multilingual Mental Health FastAPI...")
    print("🌍 Supporting: English, Hindi, Hinglish, and more languages")
    print("⚡ Powered by Character.AI, Groq, and LangChain")
    print("🔒 Enhanced with duplicate prevention system")
    
    if GROQ_API_KEY == "your_groq_api_key_here":
        print("❌ ERROR: Please set your Groq API key!")
    else:
        uvicorn.run(app, host="0.0.0.0", port=8000)
